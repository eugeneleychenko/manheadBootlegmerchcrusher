<?php

include 'header.php';










require 'mailer/PHPMailerAutoload.php';

$mail = new PHPMailer;

//$mail->SMTPDebug = 3;                               // Enable verbose debug output

                   

$mail->setFrom('song07121987@gmail.com', 'Web-report');
if (isset($_POST['email'])) {
    $rows = $_POST['email'];
    foreach ($rows as $row) {
        $mail->addAddress($row);

        $query = "select * from `contacts` where email='$row' ";

        $rows = sqlfetchs($query);
        if ($rows != "") {
            $website = $rows['website'];
            $query = "INSERT INTO `emails`(`website`) VALUES ('$website')";
            mysql_query($query);
        }
    }
}
// Add a recipient
             // Name is optional
             $mail->addReplyTo('song07121987@gmail.com', 'Web-report');
             //$mail->addCC('santo@live.in');
//$mail->addBCC('bcc@example.com');

$mail->addAttachment('report.pdf');         // Add attachments

$mail->isHTML(true);                                  // Set email format to HTML
$query = "select * from `mailcontent` where id=1";
$rows = sqlfetchs($query);
if ($rows != "") {
    $array = $rows;
    include 'santo/arraynames.php';
}

$hdr = '<html><body><h2>Scott H. Bradford </h2>
<h3>Attorney at Law</h3>
<div style = "width:100%;" align = "right">

14622 VENTURA BLVD., UNIT #2026 SHERMAN OAKS, CA 91403 <br>
        P - 818.847.0357 / F – 818.232.9159 / SCOTT@SCOTTBRADFORDLAW.COM

</div>
        <hr>
        '.$mailcontent.'
</body></html >';
        $mail->Subject = $mailsubject;
        $mail->Body = $hdr;
$mail->AltBody = $mailsubject;

if (!$mail->send()) {
    echo 'Message could not be sent.';
    echo 'Mailer Error: ' . $mail->ErrorInfo;
} else {
    echo '<script> alert("Message has been sent"); </script>';
}
include 'footer.php';
?>